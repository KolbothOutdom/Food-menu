const express = require("express")
const app = express()
const path = require("path")
const expressLayouts = require("express-ejs-layouts") // Import the middleware

app.set("view engine", "ejs")
app.set("views", path.join(__dirname, "views"))

app.use(expressLayouts) // Use the middleware
app.set("layout", "layout") // Set the default layout

app.use(express.static(path.join(__dirname, "public")))

const menuItems = [
  { name: "Hotdog", description: "chicken sausage with long buns", price: "$5" },
  {
    name: "Cheese Burger",
    description: "beef patty with cheese and tomato",
    price: "$7.50",
  },
  {
    name: "Onion Ring",
    description: "5 Fried onion rings with sauce",
    price: "$4",
  },
  {
    name: "Salad",
    description: "mix vegetables salad",
    price: "$3",
  },
]

app.get("/", (req, res) => {
  res.render("index", { menuItems })
})

const PORT = process.env.PORT || 3000
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`)
})
